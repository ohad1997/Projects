void ft_putchar(char c);
void ft_swap(int* num1, int* num2);
void ft_putstr(char* str);
void ft_strlen(char* str);
void ft_strcmp(char* s1,char* s2);
