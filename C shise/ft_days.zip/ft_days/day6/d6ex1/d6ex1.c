#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main (int argc, char* argv[])
{
	printf("%s\n",argv[0] );
	return 0;
}