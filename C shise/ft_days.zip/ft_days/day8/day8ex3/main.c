#include <stdio.h>
#include "ft_abs.h"

int main(int argc, char const *argv[])
{
	int num = -3;
	printf("%d",ABS(num));
	return 0;
}