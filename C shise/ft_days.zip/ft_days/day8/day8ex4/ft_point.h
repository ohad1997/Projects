typedef struct two_nums{
	int x;
	int y;
} t_point;
